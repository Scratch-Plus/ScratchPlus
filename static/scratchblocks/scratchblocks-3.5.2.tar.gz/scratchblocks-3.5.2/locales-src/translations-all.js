var languages = require("../locales/all")
window.scratchblocks.loadLanguages(languages)
