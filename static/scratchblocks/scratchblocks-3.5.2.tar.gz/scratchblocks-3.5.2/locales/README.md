The JSON files in this directory are output by `locales-src/build-locales.js`. The locales are extracted from the [scratchr2_translations](https://github.com/LLK/scratchr2_translations) package.
