var languages = require("../locales/forums")
window.scratchblocks.loadLanguages(languages)
