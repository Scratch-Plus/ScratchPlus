var scratchblocks = (window.scratchblocks = module.exports = require("./index")(
  window
))

// add our CSS to the page
scratchblocks.appendStyles()
